﻿using TechnicalAssignment_Creditworks.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace TechnicalAssignment_Creditworks.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Vehicle> Vehicles => Set<Vehicle>();
        public DbSet<Manufacturer> Manufacturers => Set<Manufacturer>();
        public DbSet<VehicleCategory> VehicleCategories => Set<VehicleCategory>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure decimal precision for weights
            modelBuilder.Entity<Vehicle>()
                .Property(v => v.Weight)
                .HasPrecision(18, 2);

            modelBuilder.Entity<VehicleCategory>()
                .Property(c => c.MinWeight)
                .HasPrecision(18, 2);

            modelBuilder.Entity<VehicleCategory>()
                .Property(c => c.MaxWeight)
                .HasPrecision(18, 2);

            // Seed Initial Manufacturers
            modelBuilder.Entity<Manufacturer>().HasData(
                new Manufacturer { Id = 1, Name = "Mazda" },
                new Manufacturer { Id = 2, Name = "Mercedes" },
                new Manufacturer { Id = 3, Name = "Honda" },
                new Manufacturer { Id = 4, Name = "Ferrari" },
                new Manufacturer { Id = 5, Name = "Toyota" }
            );

            // Seed Initial Categories
            modelBuilder.Entity<VehicleCategory>().HasData(
                new VehicleCategory { Id = 1, Name = "Light", MinWeight = null, MaxWeight = 500.00m, IconName = "feather" },
                new VehicleCategory { Id = 2, Name = "Medium", MinWeight = 500.00m, MaxWeight = 2500.00m, IconName = "car" },
                new VehicleCategory { Id = 3, Name = "Heavy", MinWeight = 2500.00m, MaxWeight = null, IconName = "truck" }
            );
        }
    }
}