﻿using Xunit;

namespace VehicleRegistry.Tests
{
    public class CategoryTests
    {
        [Fact]
        public void Weight_MapsToExpectedCategory_Light()
        {
            // Arrange
            double weight = 50;

            // Act
            string category = weight < 100 ? "Light" : "Heavy";

            // Assert
            Assert.Equal("Light", category);
        }

        [Fact]
        public void Weight_MapsToExpectedCategory_Medium()
        {
            // Arrange
            double weight = 500;

            // Act
            string category = (weight >= 100 && weight < 1000) ? "Medium" : "Other";

            // Assert
            Assert.Equal("Medium", category);
        }
    }
}