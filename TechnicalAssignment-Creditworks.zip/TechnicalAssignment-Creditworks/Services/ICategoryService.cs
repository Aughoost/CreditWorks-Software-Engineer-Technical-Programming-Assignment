﻿using TechnicalAssignment_Creditworks.Models;

namespace TechnicalAssignment_Creditworks.Services
{
    public interface ICategoryService
    {
        Task<VehicleCategory?> DetermineCategoryForWeightAsync(decimal weight);
        Task<(bool IsValid, string ErrorMessage)> ValidateCategoryRangesAsync(List<VehicleCategory> categoriesToTest);
    }
}
