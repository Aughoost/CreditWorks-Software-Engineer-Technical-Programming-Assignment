﻿using TechnicalAssignment_Creditworks.Data;
using TechnicalAssignment_Creditworks.Models;
using TechnicalAssignment_Creditworks.Services;
using Microsoft.EntityFrameworkCore; // <--- THIS IS MANDATORY FOR .ToListAsync()//using TechnicalAssignment_Creditworks.;
namespace CreditWorks.Backend.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly AppDbContext _context;

        public CategoryService(AppDbContext context)
        {
            _context = context;
        }

        // Automatically determine the category based on vehicle weight
        public async Task<VehicleCategory?> DetermineCategoryForWeightAsync(decimal weight)
        {
            var categories = await _context.VehicleCategories.ToListAsync();

            foreach (var cat in categories)
            {
                bool matchesMin = !cat.MinWeight.HasValue || weight >= cat.MinWeight.Value;
                bool matchesMax = !cat.MaxWeight.HasValue || weight < cat.MaxWeight.Value;

                if (!cat.MaxWeight.HasValue && weight >= cat.MinWeight.Value)
                {
                    return cat;
                }

                if (matchesMin && matchesMax)
                {
                    return cat;
                }
            }

            return categories.FirstOrDefault(c => c.MaxWeight.HasValue && weight == c.MaxWeight.Value);
        }

        // Validate complete weight coverage: no gaps and no overlaps
        public async Task<(bool IsValid, string ErrorMessage)> ValidateCategoryRangesAsync(List<VehicleCategory> categories)
        {
            if (categories == null || categories.Count == 0)
                return (false, "At least one category must exist.");

            var sortedCategories = categories
                .OrderBy(c => c.MinWeight ?? 0)
                .ToList();

            if (sortedCategories.First().MinWeight.HasValue && sortedCategories.First().MinWeight.Value > 0)
            {
                return (false, "There is a gap at the lower bound (starting weight must begin at 0).");
            }

            for (int i = 0; i < sortedCategories.Count; i++)
            {
                var current = sortedCategories[i];

                if (current.MinWeight.HasValue && current.MaxWeight.HasValue && current.MinWeight >= current.MaxWeight)
                {
                    return (false, $"Category '{current.Name}': Minimum weight must be less than maximum weight.");
                }

                if (i < sortedCategories.Count - 1)
                {
                    var next = sortedCategories[i + 1];

                    if (!current.MaxWeight.HasValue)
                    {
                        return (false, $"Category '{current.Name}' cannot have an open maximum weight because subsequent categories exist.");
                    }

                    if (!next.MinWeight.HasValue)
                    {
                        return (false, $"Category '{next.Name}' must have a defined minimum weight.");
                    }

                    if (current.MaxWeight.Value < next.MinWeight.Value)
                    {
                        return (false, $"Gap detected between '{current.Name}' (ends at {current.MaxWeight}) and '{next.Name}' (starts at {next.MinWeight}).");
                    }
                    if (current.MaxWeight.Value > next.MinWeight.Value)
                    {
                        return (false, $"Overlap detected between '{current.Name}' and '{next.Name}'.");
                    }
                }
            }

            return (true, string.Empty);
        }
    }
}
