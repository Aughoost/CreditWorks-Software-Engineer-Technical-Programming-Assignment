﻿namespace TechnicalAssignment_Creditworks.Models
{
    public class VehicleCategory
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal? MinWeight { get; set; } // Nullable for ranges like "Up to 500 kg"
        public decimal? MaxWeight { get; set; } // Nullable for ranges like "2500 kg and above"
        public string IconName { get; set; } = string.Empty;
    }
}
