﻿using TechnicalAssignment_Creditworks.Models;

namespace TechnicalAssignment_Creditworks.Services
{
    public static class CategoryRangeValidator
    {
        public class ValidationResult
        {
            public bool IsValid { get; set; }
            public List<string> Errors { get; set; } = new();
        }

        public static ValidationResult ValidateRanges(List<VehicleCategory> categories)
        {
            var result = new ValidationResult { IsValid = true };

            if (categories == null || !categories.Any())
            {
                result.IsValid = false;
                result.Errors.Add("At least one vehicle category must exist.");
                return result;
            }

         

            // Treat null MinWeight as 0.00 kg (e.g., "Up to 500 kg")
            var sorted = categories.OrderBy(c => c.MinWeight ?? 0m).ToList();

            // Rule 1: The lowest category range must cover 0.00 kg
            var lowest = sorted.First();
            if (lowest.MinWeight.HasValue && lowest.MinWeight.Value > 0m)
            {
                result.IsValid = false;
                result.Errors.Add($"The lowest category range must start at 0.00 kg. Currently starts at {lowest.MinWeight.Value:F2} kg.");
            }

            // Rule 2: Exactly one top-tier category must have MaxWeight = null ("2500 kg and above")
            var unboundedCount = sorted.Count(c => c.MaxWeight == null);
            if (unboundedCount != 1)
            {
                result.IsValid = false;
                result.Errors.Add("Exactly one top-tier category must have an unbounded upper limit ('and above').");
            }
            else if (sorted.Last().MaxWeight != null)
            {
                result.IsValid = false;
                result.Errors.Add("The category with the highest minimum weight must be the one with an unbounded upper limit.");
            }

            // Rule 3: Check for Gaps and Overlaps between adjacent ranges [Min, Max)
            for (int i = 0; i < sorted.Count - 1; i++)
            {
                var current = sorted[i];
                var next = sorted[i + 1];

                decimal currentMax = current.MaxWeight ?? 0m;
                decimal nextMin = next.MinWeight ?? 0m;

                if (!current.MaxWeight.HasValue)
                {
                    result.IsValid = false;
                    result.Errors.Add($"Category '{current.Name}' has no upper limit but is followed by '{next.Name}'.");
                    continue;
                }

                // Gap check: current Max < next Min
                if (currentMax < nextMin)
                {
                    result.IsValid = false;
                    result.Errors.Add($"Gap detected: Weights between {currentMax:F2} kg and {nextMin:F2} kg are not covered by any category.");
                }

                // Overlap check: current Max > next Min
                if (currentMax > nextMin)
                {
                    result.IsValid = false;
                    result.Errors.Add($"Overlap detected: Category '{current.Name}' ({current.MinWeight ?? 0:F2}-{currentMax:F2} kg) overlaps with '{next.Name}'.");
                }
            }

            return result;
        }
    }
}