﻿namespace TechnicalAssignment_Creditworks.Models
{
    public class Vehicle
    {
        public int Id { get; set; }
        public string OwnerName { get; set; } = string.Empty;

        public int ManufacturerId { get; set; }
        public Manufacturer? Manufacturer { get; set; } = null!;

        public int ManufactureYear { get; set; }

        // Stored in kilograms, supports up to 2 decimal places
        public decimal Weight { get; set; }
    }
}
