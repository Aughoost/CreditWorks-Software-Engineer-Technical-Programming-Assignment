﻿using TechnicalAssignment_Creditworks.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
//using TechnicalAssignment_Creditworks.Data;
using System;
using TechnicalAssignment_Creditworks.Data;
using TechnicalAssignment_Creditworks.Services;

namespace TechnicalAssignment_Creditworks.Controllers
{
    public class VehiclesController : Controller
    {
        private readonly AppDbContext _context;
        private readonly ICategoryService _categoryService;

        public VehiclesController(AppDbContext context, ICategoryService categoryService)
        {
            _context = context;
            _categoryService = categoryService;
        }

       
        // GET: Vehicles
        public async Task<IActionResult> Index(string sortOrder)
        {
            try
            {

           
            // Populate manufacturers for the modal dropdown
            ViewBag.Manufacturers = new SelectList(await _context.Manufacturers.ToListAsync(), "Id", "Name");

            var vehiclesQuery = _context.Vehicles
                .Include(v => v.Manufacturer)
                .AsQueryable();

            var vehicles = await vehiclesQuery.ToListAsync();

            var vehicleViewModels = new List<VehicleViewModel>();
            foreach (var v in vehicles)
            {
                var category = await _categoryService.DetermineCategoryForWeightAsync(v.Weight);
                vehicleViewModels.Add(new VehicleViewModel
                {
                    Id = v.Id,
                    OwnerName = v.OwnerName,
                    ManufacturerName = v.Manufacturer?.Name ?? "Unknown",
                    ManufactureYear = v.ManufactureYear,
                    Weight = v.Weight,
                    CategoryName = category?.Name ?? "Unassigned",
                    CategoryIcon = category?.IconName ?? "default"
                });
            }

            return View(vehicleViewModels);
            }
            catch (Exception ex)
            {
                // Optional: Log the exception if you have a logger configured
                // _logger.LogError(ex, "An error occurred while loading the vehicle index page.");

                // If an AJAX call triggered this, return a friendly error message or empty fallback
                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return StatusCode(500, "A database or service error occurred while refreshing the vehicle list.");
                }

                // For regular requests, you can return an empty view or pass an error message via ViewBag/TempData
                ViewBag.ErrorMessage = "Unable to load vehicle records at this time. Please try again later.";
                return View(new List<VehicleViewModel>());
            }
        }

        // GET: Vehicles/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.Manufacturers = new SelectList(await _context.Manufacturers.ToListAsync(), "Id", "Name");
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("OwnerName,ManufacturerId,ManufactureYear,Weight")] Vehicle vehicle)
        {
            // Server-side validation rules
            if (vehicle.Weight <= 0)
            {
                ModelState.AddModelError("Weight", "Weight must be a positive value greater than zero.");
            }

            if (Math.Round(vehicle.Weight, 2) != vehicle.Weight)
            {
                ModelState.AddModelError("Weight", "Weight can support a maximum of two decimal places.");
            }

            if (vehicle.ManufactureYear < 1900 || vehicle.ManufactureYear > DateTime.Now.Year + 1)
            {
                ModelState.AddModelError("ManufactureYear", "Please enter a sensible manufacture year.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(vehicle);
                    await _context.SaveChangesAsync();

                    if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                    {
                        return Json(new { success = true });
                    }

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    // Optional: Log the exception here if you have a logger configured
                    // _logger.LogError(ex, "Error saving vehicle to database.");

                    // Handle error gracefully for AJAX requests
                    if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                    {
                        return Json(new { success = false, errors = new[] { "A database error occurred while saving the vehicle. Please try again." } });
                    }

                    // Handle error for normal form posts
                    ModelState.AddModelError("", "A database error occurred while saving the vehicle. Please try again.");
                }
            }

            // Capture explicit error messages from ModelState
            var errors = ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage)
                .Where(e => !string.IsNullOrEmpty(e))
                .ToList();

            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { success = false, errors = errors });
            }

            ViewBag.Manufacturers = new SelectList(await _context.Manufacturers.ToListAsync(), "Id", "Name", vehicle.ManufacturerId);
            return View(vehicle);
        }

      

        // ViewModel for displaying vehicle information with computed category details
        public class VehicleViewModel
        {
            public int Id { get; set; }
            public string OwnerName { get; set; } = string.Empty;
            public string ManufacturerName { get; set; } = string.Empty;
            public int ManufactureYear { get; set; }
            public decimal Weight { get; set; }
            public string CategoryName { get; set; } = string.Empty;
            public string CategoryIcon { get; set; } = string.Empty;

        }
    }
}
