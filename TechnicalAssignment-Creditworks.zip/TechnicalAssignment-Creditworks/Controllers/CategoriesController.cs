﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TechnicalAssignment_Creditworks.Data; // Adjust to your DbContext namespace
using TechnicalAssignment_Creditworks.Models;
using TechnicalAssignment_Creditworks.Services;


namespace TechnicalAssignment_Creditworks.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly AppDbContext _context;

        public CategoriesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Categories
        public async Task<IActionResult> Index()
        {
            var categories = await _context.VehicleCategories
                .OrderBy(c => c.MinWeight ?? 0m)
                .ToListAsync();

            return View(categories);
        }

        // POST: Categories/Save
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Save([FromBody] List<VehicleCategory> categories)
        {
            if (categories == null || !categories.Any())
            {
                return Json(new { success = false, errors = new[] { "No category data submitted." } });
            }


            // Enforce business rules (0-gap, 0-overlap, complete coverage)
            var validation = CategoryRangeValidator.ValidateRanges(categories);
            if (!validation.IsValid)
            {
                return Json(new { success = false, errors = validation.Errors });
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Remove existing categories and re-add updated set
                var existing = await _context.VehicleCategories.ToListAsync();
                _context.VehicleCategories.RemoveRange(existing);
                await _context.SaveChangesAsync();

                await _context.VehicleCategories.AddRangeAsync(categories);
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();
                return Json(new { success = true, message = "Categories saved successfully!" });
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return Json(new { success = false, errors = new[] { $"Database Error: {ex.Message}" } });
            }
        }
    }
}